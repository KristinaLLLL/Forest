package com.example.forest

data class Lumber(
    val number: Int,
    val height: Int,
    val width: Int,
    val length: Double,
    val amount: Int
)
