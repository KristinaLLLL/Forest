package com.example.forest


import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.TextView
import butterknife.BindView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val test_lumber = Lumber(1, 50, 50, 3.0, 25)
        val stock: String
        val txt: TextView = findViewById(R.id.stock)
        txt.text = test_lumber.toString()

        println("Пиломатериалы: $test_lumber")
    }
}